import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgreementComponent } from './agreement-component';

describe('AgreementComponent', () => {
  let component: AgreementComponent;
  let fixture: ComponentFixture<AgreementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AgreementComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AgreementComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
